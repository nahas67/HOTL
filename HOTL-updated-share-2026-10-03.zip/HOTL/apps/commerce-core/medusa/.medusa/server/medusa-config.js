"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
(0, utils_1.loadEnv)(process.env.NODE_ENV ?? "development", process.cwd());
function required(name) {
    const value = process.env[name];
    if (!value)
        throw new Error(`${name} must be configured; see .env.example`);
    return value;
}
module.exports = (0, utils_1.defineConfig)({
    admin: { disable: true },
    projectConfig: {
        databaseUrl: required("MEDUSA_DATABASE_URL"),
        redisUrl: required("REDIS_URL"),
        http: {
            storeCors: process.env.STORE_CORS ?? "http://localhost:3001",
            adminCors: process.env.ADMIN_CORS ?? "http://localhost:7001",
            authCors: process.env.AUTH_CORS ?? "http://localhost:3001,http://localhost:7001",
            jwtSecret: required("MEDUSA_JWT_SECRET"),
            cookieSecret: required("MEDUSA_COOKIE_SECRET"),
        },
    },
    modules: [
        {
            resolve: "@medusajs/medusa/payment",
            options: {
                providers: [{
                        resolve: "./src/modules/guarded-payment",
                        id: "guarded",
                        options: { guardrailUrl: required("GUARDRAIL_URL"), guardrailToken: required("MEDUSA_GUARDRAIL_TOKEN") },
                    }],
            },
        },
        {
            resolve: "@medusajs/medusa/event-bus-redis",
            options: {
                redisUrl: required("REDIS_URL"),
                queueName: "medusa-events",
                jobOptions: { attempts: 10, backoff: { type: "exponential", delay: 1000 }, removeOnComplete: { age: 604800 }, removeOnFail: false },
            },
        },
    ],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVkdXNhLWNvbmZpZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL21lZHVzYS1jb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBa0U7QUFFbEUsSUFBQSxlQUFPLEVBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLElBQUksYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBRTlELFNBQVMsUUFBUSxDQUFDLElBQVk7SUFDNUIsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNoQyxJQUFJLENBQUMsS0FBSztRQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsR0FBRyxJQUFJLHVDQUF1QyxDQUFDLENBQUM7SUFDNUUsT0FBTyxLQUFLLENBQUM7QUFDZixDQUFDO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFBLG9CQUFZLEVBQUM7SUFDNUIsS0FBSyxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRTtJQUN4QixhQUFhLEVBQUU7UUFDYixXQUFXLEVBQUUsUUFBUSxDQUFDLHFCQUFxQixDQUFDO1FBQzVDLFFBQVEsRUFBRSxRQUFRLENBQUMsV0FBVyxDQUFDO1FBQy9CLElBQUksRUFBRTtZQUNKLFNBQVMsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsSUFBSSx1QkFBdUI7WUFDNUQsU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLHVCQUF1QjtZQUM1RCxRQUFRLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLElBQUksNkNBQTZDO1lBQ2hGLFNBQVMsRUFBRSxRQUFRLENBQUMsbUJBQW1CLENBQUM7WUFDeEMsWUFBWSxFQUFFLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQztTQUMvQztLQUNGO0lBQ0QsT0FBTyxFQUFFO1FBQ1A7WUFDRSxPQUFPLEVBQUUsMEJBQTBCO1lBQ25DLE9BQU8sRUFBRTtnQkFDUCxTQUFTLEVBQUUsQ0FBQzt3QkFDVixPQUFPLEVBQUUsK0JBQStCO3dCQUN4QyxFQUFFLEVBQUUsU0FBUzt3QkFDYixPQUFPLEVBQUUsRUFBRSxZQUFZLEVBQUUsUUFBUSxDQUFDLGVBQWUsQ0FBQyxFQUFFLGNBQWMsRUFBRSxRQUFRLENBQUMsd0JBQXdCLENBQUMsRUFBRTtxQkFDekcsQ0FBQzthQUNIO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSxrQ0FBa0M7WUFDM0MsT0FBTyxFQUFFO2dCQUNQLFFBQVEsRUFBRSxRQUFRLENBQUMsV0FBVyxDQUFDO2dCQUMvQixTQUFTLEVBQUUsZUFBZTtnQkFDMUIsVUFBVSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsRUFBRSxnQkFBZ0IsRUFBRSxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFO2FBQ3BJO1NBQ0Y7S0FDRjtDQUNGLENBQUMsQ0FBQyJ9