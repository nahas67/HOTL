"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.denyUnsupportedWrite = denyUnsupportedWrite;
const http_1 = require("@medusajs/framework/http");
function denyUnsupportedWrite(req, res, next) {
    if (["GET", "HEAD", "OPTIONS"].includes(req.method))
        return next();
    return res.status(503).json({ type: "guardrail_unavailable", message: "Native commerce mutations require the central Medusa guardrail workflow, which is not enabled in this staging adapter." });
}
// Medusa includes a default system payment provider. Restricting only our custom
// provider would leave native checkout and other commerce writes outside HOTL's
// audit boundary. Keep the staging HTTP surface read-only until guarded workflows
// are implemented; selecting another provider must not bypass that boundary.
exports.default = (0, http_1.defineMiddlewares)({ routes: [
        { matcher: "/admin/*", middlewares: [denyUnsupportedWrite] },
        { matcher: "/store/*", middlewares: [denyUnsupportedWrite] },
    ] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlkZGxld2FyZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvYXBpL21pZGRsZXdhcmVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUEsb0RBR0M7QUFMRCxtREFBK0g7QUFFL0gsU0FBZ0Isb0JBQW9CLENBQUMsR0FBa0IsRUFBRSxHQUFtQixFQUFFLElBQXdCO0lBQ3BHLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO1FBQUUsT0FBTyxJQUFJLEVBQUUsQ0FBQztJQUNuRSxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLHVCQUF1QixFQUFFLE9BQU8sRUFBRSx3SEFBd0gsRUFBRSxDQUFDLENBQUM7QUFDcE0sQ0FBQztBQUVELGlGQUFpRjtBQUNqRixnRkFBZ0Y7QUFDaEYsa0ZBQWtGO0FBQ2xGLDZFQUE2RTtBQUM3RSxrQkFBZSxJQUFBLHdCQUFpQixFQUFDLEVBQUUsTUFBTSxFQUFFO1FBQ3pDLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFO1FBQzVELEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFO0tBQzdELEVBQUUsQ0FBQyxDQUFDIn0=