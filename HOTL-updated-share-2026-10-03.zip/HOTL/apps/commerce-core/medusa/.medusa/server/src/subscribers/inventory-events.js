"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = inventoryEvents;
const commerce_events_1 = require("../lib/commerce-events");
async function inventoryEvents({ event }) {
    await (0, commerce_events_1.publishCommerceEvent)(event);
}
exports.config = {
    event: ["inventory.inventory-level.created", "inventory.inventory-level.updated", "inventory.inventory-level.deleted"],
    context: { subscriberId: "hotl-inventory-events" },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW52ZW50b3J5LWV2ZW50cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zdWJzY3JpYmVycy9pbnZlbnRvcnktZXZlbnRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUdBLGtDQUVDO0FBSkQsNERBQThEO0FBRS9DLEtBQUssVUFBVSxlQUFlLENBQUMsRUFBRSxLQUFLLEVBQWtDO0lBQ3JGLE1BQU0sSUFBQSxzQ0FBb0IsRUFBQyxLQUFLLENBQUMsQ0FBQztBQUNwQyxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQXFCO0lBQ3RDLEtBQUssRUFBRSxDQUFDLG1DQUFtQyxFQUFFLG1DQUFtQyxFQUFFLG1DQUFtQyxDQUFDO0lBQ3RILE9BQU8sRUFBRSxFQUFFLFlBQVksRUFBRSx1QkFBdUIsRUFBRTtDQUNuRCxDQUFDIn0=