"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const guarded_payments_1 = require("../../lib/guarded-payments");
function reference(data) {
    if (typeof data?.paymentReference !== "string" || !data.paymentReference)
        throw new Error("Missing central payment reference");
    return data.paymentReference;
}
function sessionId(data) {
    return typeof data?.medusaSessionId === "string" ? data.medusaSessionId : undefined;
}
function publicData(receipt, medusaSessionId) {
    return {
        paymentReference: receipt.providerPaymentId,
        receiptId: receipt.receiptId,
        operationId: receipt.operationId,
        status: receipt.status,
        ...(medusaSessionId ? { medusaSessionId } : {}),
        ...(receipt.clientSecret ? { client_secret: receipt.clientSecret } : {}),
    };
}
function medusaStatus(status) {
    if (status === "deleted")
        return "canceled";
    if (status === "refunded")
        return "captured";
    return status;
}
class GuardedPaymentProviderService extends utils_1.AbstractPaymentProvider {
    static identifier = "hotl-guarded";
    bridge;
    static validateOptions(options) { (0, guarded_payments_1.validateBridgeOptions)(options); }
    constructor(container, options) {
        super(container, options);
        this.bridge = new guarded_payments_1.GuardedPayments(options);
    }
    async initiatePayment(input) {
        // session_id is supplied by Medusa's payment module. The bridge must verify
        // ownership and binding server-side; data is never an authorization source.
        const medusaSessionId = typeof input.data?.session_id === "string" ? input.data.session_id : undefined;
        const receipt = await this.bridge.execute("initiate", {
            idempotencyKey: input.context?.idempotency_key,
            medusaSessionId,
            amount: utils_1.MathBN.convert(input.amount).toString(),
            currency: input.currency_code.toLowerCase(),
        });
        return { id: receipt.providerPaymentId, status: medusaStatus(receipt.status), data: publicData(receipt, medusaSessionId) };
    }
    async authorizePayment(input) {
        const receipt = await this.bridge.execute("authorize", { idempotencyKey: input.context?.idempotency_key, paymentReference: reference(input.data), medusaSessionId: sessionId(input.data) });
        return { status: medusaStatus(receipt.status), data: publicData(receipt, sessionId(input.data)) };
    }
    async capturePayment(input) {
        const receipt = await this.bridge.execute("capture", { idempotencyKey: input.context?.idempotency_key, paymentReference: reference(input.data), medusaSessionId: sessionId(input.data) });
        return { data: publicData(receipt, sessionId(input.data)) };
    }
    async refundPayment(input) {
        const receipt = await this.bridge.execute("refund", { idempotencyKey: input.context?.idempotency_key, paymentReference: reference(input.data), medusaSessionId: sessionId(input.data), amount: utils_1.MathBN.convert(input.amount).toString() });
        return { data: publicData(receipt, sessionId(input.data)) };
    }
    async cancelPayment(input) {
        const receipt = await this.bridge.execute("cancel", { idempotencyKey: input.context?.idempotency_key, paymentReference: reference(input.data), medusaSessionId: sessionId(input.data) });
        return { data: publicData(receipt, sessionId(input.data)) };
    }
    async deletePayment(input) {
        const receipt = await this.bridge.execute("delete", { idempotencyKey: input.context?.idempotency_key, paymentReference: reference(input.data), medusaSessionId: sessionId(input.data) });
        return { data: publicData(receipt, sessionId(input.data)) };
    }
    async updatePayment(input) {
        const receipt = await this.bridge.execute("update", { idempotencyKey: input.context?.idempotency_key, paymentReference: reference(input.data), medusaSessionId: sessionId(input.data), amount: utils_1.MathBN.convert(input.amount).toString(), currency: input.currency_code.toLowerCase() });
        return { status: medusaStatus(receipt.status), data: publicData(receipt, sessionId(input.data)) };
    }
    async retrievePayment(input) {
        return { data: publicData(await this.bridge.retrieve(reference(input.data)), sessionId(input.data)) };
    }
    async getPaymentStatus(input) {
        const receipt = await this.bridge.retrieve(reference(input.data));
        return { status: medusaStatus(receipt.status) };
    }
    async getWebhookActionAndData(_payload) {
        // Stripe webhooks terminate and are authenticated centrally. Until a signed
        // central webhook contract exists, inbound payloads cannot advance payment.
        return { action: "not_supported" };
    }
}
exports.default = GuardedPaymentProviderService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2d1YXJkZWQtcGF5bWVudC9zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBQTRFO0FBUTVFLGlFQUFtSjtBQUVuSixTQUFTLFNBQVMsQ0FBQyxJQUF5QztJQUMxRCxJQUFJLE9BQU8sSUFBSSxFQUFFLGdCQUFnQixLQUFLLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0I7UUFBRSxNQUFNLElBQUksS0FBSyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7SUFDL0gsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7QUFDL0IsQ0FBQztBQUVELFNBQVMsU0FBUyxDQUFDLElBQXlDO0lBQzFELE9BQU8sT0FBTyxJQUFJLEVBQUUsZUFBZSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3RGLENBQUM7QUFFRCxTQUFTLFVBQVUsQ0FBQyxPQUF5QixFQUFFLGVBQXdCO0lBQ3JFLE9BQU87UUFDTCxnQkFBZ0IsRUFBRSxPQUFPLENBQUMsaUJBQWlCO1FBQzNDLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUztRQUM1QixXQUFXLEVBQUUsT0FBTyxDQUFDLFdBQVc7UUFDaEMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNO1FBQ3RCLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEVBQUUsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUMvQyxHQUFHLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxhQUFhLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7S0FDekUsQ0FBQztBQUNKLENBQUM7QUFFRCxTQUFTLFlBQVksQ0FBQyxNQUFxQjtJQUN6QyxJQUFJLE1BQU0sS0FBSyxTQUFTO1FBQUUsT0FBTyxVQUFVLENBQUM7SUFDNUMsSUFBSSxNQUFNLEtBQUssVUFBVTtRQUFFLE9BQU8sVUFBVSxDQUFDO0lBQzdDLE9BQU8sTUFBTSxDQUFDO0FBQ2hCLENBQUM7QUFFRCxNQUFxQiw2QkFBOEIsU0FBUSwrQkFBc0M7SUFDL0YsTUFBTSxDQUFDLFVBQVUsR0FBRyxjQUFjLENBQUM7SUFDekIsTUFBTSxDQUFrQjtJQUVsQyxNQUFNLENBQUMsZUFBZSxDQUFDLE9BQXNCLElBQUksSUFBQSx3Q0FBcUIsRUFBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFbEYsWUFBWSxTQUFrQyxFQUFFLE9BQXNCO1FBQ3BFLEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDMUIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLGtDQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELEtBQUssQ0FBQyxlQUFlLENBQUMsS0FBMkI7UUFDL0MsNEVBQTRFO1FBQzVFLDRFQUE0RTtRQUM1RSxNQUFNLGVBQWUsR0FBRyxPQUFPLEtBQUssQ0FBQyxJQUFJLEVBQUUsVUFBVSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUN2RyxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRTtZQUNwRCxjQUFjLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxlQUFlO1lBQzlDLGVBQWU7WUFDZixNQUFNLEVBQUUsY0FBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxFQUFFO1lBQy9DLFFBQVEsRUFBRSxLQUFLLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRTtTQUM1QyxDQUFDLENBQUM7UUFDSCxPQUFPLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDLE9BQU8sRUFBRSxlQUFlLENBQUMsRUFBRSxDQUFDO0lBQzdILENBQUM7SUFFRCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsS0FBNEI7UUFDakQsTUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRSxjQUFjLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxlQUFlLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDNUwsT0FBTyxFQUFFLE1BQU0sRUFBRSxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxVQUFVLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQ3BHLENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLEtBQTBCO1FBQzdDLE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUUsY0FBYyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsZUFBZSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzFMLE9BQU8sRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUM5RCxDQUFDO0lBRUQsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUF5QjtRQUMzQyxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLGNBQWMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLGVBQWUsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxjQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDMU8sT0FBTyxFQUFFLElBQUksRUFBRSxVQUFVLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQzlELENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLEtBQXlCO1FBQzNDLE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEVBQUUsY0FBYyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsZUFBZSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3pMLE9BQU8sRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUM5RCxDQUFDO0lBRUQsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUF5QjtRQUMzQyxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLGNBQWMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLGVBQWUsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN6TCxPQUFPLEVBQUUsSUFBSSxFQUFFLFVBQVUsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFDOUQsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBeUI7UUFDM0MsTUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxjQUFjLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxlQUFlLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsY0FBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsUUFBUSxFQUFFLEtBQUssQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZSLE9BQU8sRUFBRSxNQUFNLEVBQUUsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUNwRyxDQUFDO0lBRUQsS0FBSyxDQUFDLGVBQWUsQ0FBQyxLQUEyQjtRQUMvQyxPQUFPLEVBQUUsSUFBSSxFQUFFLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUN4RyxDQUFDO0lBRUQsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEtBQTRCO1FBQ2pELE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ2xFLE9BQU8sRUFBRSxNQUFNLEVBQUUsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO0lBQ2xELENBQUM7SUFFRCxLQUFLLENBQUMsdUJBQXVCLENBQUMsUUFBMkM7UUFDdkUsNEVBQTRFO1FBQzVFLDRFQUE0RTtRQUM1RSxPQUFPLEVBQUUsTUFBTSxFQUFFLGVBQWUsRUFBRSxDQUFDO0lBQ3JDLENBQUM7O0FBbkVILGdEQW9FQyJ9