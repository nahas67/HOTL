"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = orderEvents;
const commerce_events_1 = require("../lib/commerce-events");
async function orderEvents({ event }) {
    // Do not swallow queue failures: Medusa's Redis event bus retries this delivery.
    await (0, commerce_events_1.publishCommerceEvent)(event);
}
exports.config = {
    event: ["order.placed", "order.canceled", "order.fulfillment_created"],
    context: { subscriberId: "hotl-order-events" },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3JkZXItZXZlbnRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL29yZGVyLWV2ZW50cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFHQSw4QkFHQztBQUxELDREQUE4RDtBQUUvQyxLQUFLLFVBQVUsV0FBVyxDQUFDLEVBQUUsS0FBSyxFQUFrQztJQUNqRixpRkFBaUY7SUFDakYsTUFBTSxJQUFBLHNDQUFvQixFQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3BDLENBQUM7QUFFWSxRQUFBLE1BQU0sR0FBcUI7SUFDdEMsS0FBSyxFQUFFLENBQUMsY0FBYyxFQUFFLGdCQUFnQixFQUFFLDJCQUEyQixDQUFDO0lBQ3RFLE9BQU8sRUFBRSxFQUFFLFlBQVksRUFBRSxtQkFBbUIsRUFBRTtDQUMvQyxDQUFDIn0=